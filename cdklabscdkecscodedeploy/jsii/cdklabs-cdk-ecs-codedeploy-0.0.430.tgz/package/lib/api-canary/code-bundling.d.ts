import { BundlingOptions, ILocalBundling } from 'aws-cdk-lib';
export declare class CanaryCodeBundler implements ILocalBundling {
    readonly codePath: string;
    constructor(codePath: string);
    copy(pattern: RegExp, outputDir: string): void;
    tryBundle(outputDir: string, _options: BundlingOptions): boolean;
    toJSON(): object;
}
