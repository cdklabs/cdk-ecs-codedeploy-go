import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
/**
 * Props for OnEventFunction
 */
export interface OnEventFunctionProps extends lambda.FunctionOptions {
}
/**
 * An AWS Lambda function which executes src/ecs-deployment-provider/on-event.
 */
export declare class OnEventFunction extends lambda.Function {
    constructor(scope: Construct, id: string, props?: OnEventFunctionProps);
}
