import * as lambda from 'aws-cdk-lib/aws-lambda';
import { Construct } from 'constructs';
/**
 * Props for IsCompleteFunction
 */
export interface IsCompleteFunctionProps extends lambda.FunctionOptions {
}
/**
 * An AWS Lambda function which executes src/ecs-deployment-provider/is-complete.
 */
export declare class IsCompleteFunction extends lambda.Function {
    constructor(scope: Construct, id: string, props?: IsCompleteFunctionProps);
}
