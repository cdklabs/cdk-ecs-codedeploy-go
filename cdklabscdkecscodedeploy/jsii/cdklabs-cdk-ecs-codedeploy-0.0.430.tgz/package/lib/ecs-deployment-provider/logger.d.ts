type LogAttributes = {
    [key: string]: string | boolean | Error | undefined;
};
export declare class Logger {
    persistentAttributes: LogAttributes;
    info(message: string, ...attributes: LogAttributes[]): void;
    warn(message: string, ...attributes: LogAttributes[]): void;
    error(message: string, ...attributes: LogAttributes[]): void;
    appendKeys(attributes: LogAttributes): void;
    formatMessage(message: string, ...attributes: LogAttributes[]): string;
}
export {};
